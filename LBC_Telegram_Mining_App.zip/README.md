# LBC Telegram Mining App

This ZIP contains a simple Telegram Mini App frontend for an LBC mining interface.

## Included
- Telegram Web App integration
- LBC balance display
- Start/stop mining button
- Session timer
- Demo reward counter
- Responsive mobile UI

## Important
The current mining/reward logic is **frontend demo logic only** and stores the balance in the browser's local storage. Do not use it for real token balances.

For a real production app, add:
1. Backend API
2. Database
3. Telegram initData validation on the server
4. Server-side balance/reward calculations
5. Authentication and anti-abuse controls
6. HTTPS hosting
7. BotFather Web App URL configuration

## GitHub
Upload all files in this folder to a GitHub repository. GitHub Pages can host the frontend if the project does not require server-side code.
