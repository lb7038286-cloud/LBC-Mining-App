const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
}

const user = tg?.initDataUnsafe?.user;
document.getElementById("user").textContent =
  user ? `Welcome, ${user.first_name || "Miner"}` : "Open this app inside Telegram";

let balance = Number(localStorage.getItem("lbc_balance") || 0);
let running = false;
let seconds = 0;
let session = 0;
let interval = null;
const ratePerSecond = 0.10 / 60;

function render() {
  document.getElementById("balance").textContent = balance.toFixed(2);
  document.getElementById("session").textContent = session.toFixed(2) + " LBC";
  const h = String(Math.floor(seconds / 3600)).padStart(2,"0");
  const m = String(Math.floor((seconds % 3600) / 60)).padStart(2,"0");
  const s = String(seconds % 60).padStart(2,"0");
  document.getElementById("timer").textContent = `${h}:${m}:${s}`;
  document.getElementById("status").textContent = running ? "Mining active" : "Mining stopped";
  document.getElementById("statusDot").style.background = running ? "#22c55e" : "#64748b";
  const btn = document.getElementById("mineBtn");
  btn.textContent = running ? "Stop Mining" : "Start Mining";
  btn.classList.toggle("stop", running);
}

document.getElementById("mineBtn").addEventListener("click", () => {
  running = !running;
  if (running) {
    interval = setInterval(() => {
      seconds++;
      const reward = ratePerSecond;
      balance += reward;
      session += reward;
      localStorage.setItem("lbc_balance", balance.toFixed(8));
      render();
    }, 1000);
  } else {
    clearInterval(interval);
  }
  render();
});

render();
